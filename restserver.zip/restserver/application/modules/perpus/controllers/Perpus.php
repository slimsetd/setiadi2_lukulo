<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//http://stackoverflow.com/questions/18382740/cors-not-working-php
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

    exit(0);
}

class Perpus extends CI_Controller {

	public function __construct() {
		parent::__construct();
		//error_reporting(1);
		date_default_timezone_set("Asia/Jakarta"); 
		$postdata = file_get_contents("php://input");
		$this->request = json_decode($postdata);
		$this->load->model('Model_api');
	}

	public function index() {
		echo "string";
	}

	public function login() {
		$member_id = $this->request->member_id;
		$password = $this->request->password;

		$member = $this->db->get_where('member', array('member_id' => $member_id, 'member_type_id' => 1))->row_array();

		if (count($member) > 0) {
			if (password_verify($password, $member['mpasswd'])) {
				$data = array(
					'success' => true,
					'member' => $member
				);
			} else {
				$data = array(
					'success' => false,
					'message' => 'Member ID atau password salah'
				);
			}
		}  else {
			$data = array(
				'success' => false,
				'message' => 'Member ID atau password salah'
			);	
		}

		echo json_encode($data);
	}

	private function getDataBuku($table, $biblio_id) {
		$buku = $this->db->select('A.*, B.item_code, C.location, C.status, D.item_status_name, E.due_date')->order_by('A.biblio_id','desc')
			->where('A.biblio_id', $biblio_id)
			->join('item B', 'A.biblio_id = B.biblio_id', 'left')
			->join('stock_take_item C', 'B.item_id = C.item_id', 'left')
			->join('mst_item_status D', 'B.item_status_id = D.item_status_id', 'left')
			->join('loan E', 'B.item_id = D.item_id', 'left')
			->get($table.' A')->result();
		echo json_encode($buku);
	}

	public function getBukuDetail($id) {
		$buku = $this->db->get_where('search_biblio', array('biblio_id' => $id))->row_array();

		$item = $this->db->get_where('item',array('biblio_id' => $buku['biblio_id']))->row_array();

		$kondisi = $this->db->get_where('mst_item_status',array('item_status_id' => $item['item_status_id']))->row_array();

		if ($kondisi = MIS) {
			$data = array(
				'kondisi' => 'Hilang'
			);
		} else {
			$data = array(
				'kondisi' => 'Rusak'
			);
		}

		$loan = $this->db->get_where('loan',array('item_id' => $item['item_id']));

		$status = $this->db->get_where('status',array('item_id' => $item['item_id']));	

		if ($status = l) {
			$data = array(
				'status' => 'Buku Sedang Dipinjam'
			);
		} else {
			$data = array(
				'status' => 'Tersedia'
			);
		}

		$data = array(
			'item_code'        => $item['item_code'],
			'call_number'      => $status['call_number'],
			'status'   		   => $status,
			'kondisi'      	   => $kondisi,
			'due_date'         => $loan['due_date'],
			'series_title'     => $buku['series_title'],
			'publisher' 	   => $buku['publisher'],
			'publish_place'    => $buku['publish_place'],
			'publish_year'	   => $buku['publish_year'],
			'collation'   	   => $buku['collation'],
			'language' 	 	   => $buku['language'],
			'isbn_issn'   	   => $buku['isbn_issn'],
			'content_type'	   => $buku['content_type'],
			'media_type'   	   => $buku['media_type'],
			'carrier_type' 	   => $buku['carrier_type'],
			'topic'   	   	   => $buku['topic'],
			'edition'	 	   => $buku['edition'],			
		);

		echo json_encode($data,JSON_NUMERIC_CHECK);
	}

	public function getDaftarPeminjaman() {
		$pinjam = $this->db->select('A.member_id, B.debet, B.kredit, C.loan_date, C.due_date, D.item_code, E.title')->order_by('A.member_id','desc')
			->where('A.biblio_id', $biblio_id)
			->join('item B', 'A.biblio_id = B.biblio_id', 'left')
			->join('stock_take_item C', 'B.item_id = C.item_id', 'left')
			->join('mst_item_status D', 'B.item_status_id = D.item_status_id', 'left')
			->join('loan E', 'B.item_id = D.item_id', 'left')
			->get($table.' A')->result();
		echo json_encode($buku);

	}

	public function createHarga() {
		$postData = array(
			'id_bengkel'     => $this->request->id_bengkel,
			'id_model_motor' => $this->request->id_model_motor,
			'nama_perawatan' => $this->request->nama_perawatan,
			'harga'          => $this->request->harga
		);
		$this->db->insert('harga_perawatan', $postData);

		$data = array(
			'response'    => 'OK',
			'status'      => 'Success',
		);

		echo json_encode($data);
	}

	public function updateHarga() {
		$id['id_harga'] = $this->request->id_harga;
		$postData = array(
			'nama_perawatan' => $this->request->nama_perawatan,
			'harga'          => $this->request->harga
		);
		$this->db->update('harga_perawatan', $postData, $id);

		$data = array(
			'response'    => 'OK',
			'status'      => 'Success',
		);

		echo json_encode($data);
	}

	private function getPemesanan($table, $id_bengkel) {
		$pemesanan = $this->db->select('A.*, B.nama, C.nama_model')->order_by('A.no_pemesanan','desc')
			->where('A.id_bengkel', $id_bengkel)
			->join('pelanggan B', 'A.id_pelanggan = B.id_pelanggan', 'left')
			->join('model_sepeda_motor C', 'A.id_model_motor = C.id_model', 'left')
			->get($table.' A')->result();
		return $pemesanan;
	}

	public function getListPemesanan() {
		$id_bengkel = $this->request->id_bengkel;

		$sukucadang = $this->getPemesanan('pemesanan_sukucadang', $id_bengkel);

		foreach ($sukucadang as $row) {
			$detail_sukucadang = $this->db->where('no_pemesanan', $row->no_pemesanan)->get('detail_pemesanan_sukucadang')->result();
			$row->detail_sukucadang = $detail_sukucadang;
			$row->tgl_pemesanan = date('d M Y', strtotime($row->tgl_pemesanan));
		}

		$perawatan = $this->getPemesanan('pemesanan_perawatan', $id_bengkel);

		foreach ($perawatan as $row) {
			$detail_perawatan = $this->db->select('A.*, B.nama_perawatan')->order_by('A.no_pemesanan','desc')
			->where('A.no_pemesanan', $row->no_pemesanan)
			->join('harga_perawatan B', 'A.id_harga_perawatan = B.id_harga', 'left')
			->get('detail_pemesanan_perawatan A')->result();

			$row->detail_perawatan = $detail_perawatan;

			if ($row->waktu_booking > date('Y-m-d H:i:s')) {
				$row->status = 'Baru';
			} else {
				$row->status = 'Selesai';
			}

			$row->waktu_booking = date('d M Y H:i', strtotime($row->waktu_booking));
		}

		$data = array(
			'response'   => 'OK',
			'status'     => 'Success',
			'perawatan'  => $perawatan,
			'sukucadang' => $sukucadang,
		);

		echo json_encode($data);
	}

	public function updateDetailSukucadang() {
		$data = array(
			'id_detail' => $this->request->id_detail,
			'harga'     => $this->request->harga,
			'status'    => $this->request->status,
		);
		$this->db->update('detail_pemesanan_sukucadang', $data);

		$data = array(
			'response' => 'OK',
			'status'   => 'Success',
			'message'  => 'Detail sukucadang berhasil diperbarui'
		);

		echo json_encode($data);
	}

}